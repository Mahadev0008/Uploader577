# All_In_One BOT

## BATCH EXTRACTOR AND DOWNLOADER


[![Open Source? Yes!](https://badgen.net/badge/Open%20Source%20%3F/Yes%21/blue?icon=github)](https://github.com/cryptostark/All_In_One/tree/main)
[![Ask Me Anything !](https://img.shields.io/badge/Ask%20me-anything-1abc9c.svg)](https://telegram.dog/starky0)

## How to Deploy? 🤔
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/cryptostark/All_In_One)
- 👆 Press the deploy button.

- Go to  [my.telegram.org](https://my.telegram.org/)
     - And get your API ID
     - And API Hashes

- Get the Bot Father Token from [@BotFather](https://telegram.dog/botfather)




## How to reach Me ?
<a href="https://telegram.dog/starky0"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
<a href="https://telegram.dog/starkbotss"><img src="https://img.shields.io/badge/Join-Telegram%20Group-blue.svg?logo=telegram"></a>

## COMMANDS
### AVAILABLE COMMANDS 
```
start - check whether bot is alive 
pw - For Physics Wallah..
e1 - For E1 Coaching App..
vidya - For Vidya Bihar App..
ocean - For Ocean Gurukul App..
winners - For The Winners Institute.
rgvikramjeet - For Rgvikramjeet App..
txt - Rojgar with ankit
cp - For classplus app
cw - For careerwill app..
exampur - For exampur app..
khan - Khan Gs app..
down - For Downloading Url lists
forward - To Forward from One 
restart - To restart the bot
```

[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

## License
[![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://github.com/cryptostark/All_In_One/blob/main/LICENCE)
